package example.biud436.com.xwalkproject;

import android.os.Bundle;

import com.unity3d.player.UnityPlayerActivity;

/**
 * Created by U on 2017-05-13.
 */
public class CUnityPlayerActivity extends UnityPlayerActivity {
    @Override
    public void onCreate(Bundle bundle) {
        requestWindowFeature(1);
        super.onCreate(bundle);
        getWindow().setFormat(2);
        mUnityPlayer = new CUnityPlayer(this);
        setContentView(mUnityPlayer);
        mUnityPlayer.requestFocus();
    }
}
