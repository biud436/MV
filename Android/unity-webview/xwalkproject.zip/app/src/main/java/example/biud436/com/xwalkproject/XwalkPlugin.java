/*
 * Copyright (C) 2011 Keijiro Takahashi
 * Copyright (C) 2012 GREE, Inc.
 *
 * This software is provided 'as-is', without any express or implied
 * warranty.  In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 */

// I have converted an Android WebView to a Crosswalk Project.

package example.biud436.com.xwalkproject;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

import org.xwalk.core.JavascriptInterface;
import org.xwalk.core.XWalkNavigationHistory;
import org.xwalk.core.XWalkResourceClient;
import org.xwalk.core.XWalkSettings;
import org.xwalk.core.XWalkUIClient;
import org.xwalk.core.XWalkView;
import org.xwalk.core.XWalkWebResourceRequest;
import org.xwalk.core.XWalkWebResourceResponse;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Hashtable;

/**
 * Created by U on 2017-05-13.
 */

class CXwalkPluginInterface {
    private XwalkPlugin mPlugin;
    private String mGameObject;

    public CXwalkPluginInterface(XwalkPlugin plugin, String gameObject) {
        mPlugin = plugin;
        mGameObject = gameObject;
    }

    @JavascriptInterface
    public void call(final String message) {
        call("CallFromJS", message);
    }

    public void call(final String method, final String message) {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mPlugin.IsInitialized()) {
                    UnityPlayer.UnitySendMessage(mGameObject, method, message);
                }
            }
        });
    }
	
	@JavascriptInterface
	public void ShowRewardedAd() {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mPlugin.IsInitialized()) {
                    UnityPlayer.UnitySendMessage("SampleWebView", "ShowRewardedAd", "");
                }
            }
        });		
	}
}

public class XwalkPlugin {
    private static FrameLayout layout = null;
    private XWalkView mWebView;
    private CXwalkPluginInterface mWebViewPlugin;
    private boolean canGoBack;
    private boolean canGoForward;
    private Hashtable<String, String> mCustomHeaders;

    public XwalkPlugin() {
    }

    public boolean IsInitialized() {
        return mWebView != null;
    }

    public void Init(final String gameObject, final boolean transparent) {
        final XwalkPlugin self = this;
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mWebView != null) {
                    return;
                }
                mCustomHeaders = new Hashtable<String, String>();

                final XWalkView webView = new XWalkView(a);
				webView.setUIClient(new XWalkUIClient(webView));				
                webView.setVisibility(View.VISIBLE);
                webView.setFocusable(true);
                webView.setFocusableInTouchMode(true);

                mWebViewPlugin = new CXwalkPluginInterface(self, gameObject);

//                XWalkPreferences.setValue(XWalkPreferences.REMOTE_DEBUGGING, true);

                webView.loadUrl("file:///android_asset/index.html");

                webView.setResourceClient(new XWalkResourceClient(webView) {
                    @Override
                    public void onReceivedLoadError(XWalkView view, int errorCode, String description, String failingUrl) {
                        webView.loadUrl("about:blank");
                        canGoBack = webView.getNavigationHistory().canGoBack();
                        canGoForward = webView.getNavigationHistory().canGoForward();
                        mWebViewPlugin.call("CallOnError", errorCode + "\t" + description + "\t" + failingUrl);
                    }

                    @Override
                    public void onLoadStarted(XWalkView view, String url) {
                        canGoBack = webView.getNavigationHistory().canGoBack();
                        canGoForward = webView.getNavigationHistory().canGoForward();
                    }

                    @Override
                    public void onLoadFinished(XWalkView view, String url) {
                        canGoBack = webView.getNavigationHistory().canGoBack();
                        canGoForward = webView.getNavigationHistory().canGoForward();
                        mWebViewPlugin.call("CallOnLoaded", url);
                    }

                    @Override
                    public XWalkWebResourceResponse shouldInterceptLoadRequest(XWalkView view, XWalkWebResourceRequest request) {
                        String url = request.getUrl().toString();
                        if (mCustomHeaders == null || mCustomHeaders.isEmpty()) {
                            return super.shouldInterceptLoadRequest(view, request);
                        }

                        try {

                            HttpURLConnection urlCon = (HttpURLConnection) (new URL(url)).openConnection();

                            for (HashMap.Entry<String, String> entry: mCustomHeaders.entrySet()) {
                                urlCon.setRequestProperty(entry.getKey(), entry.getValue());
                            }

                            urlCon.connect();

                            XWalkResourceClient xwalkResCnt = new XWalkResourceClient(mWebView);

                            return xwalkResCnt.createXWalkWebResourceResponse(
                                    urlCon.getContentType(),
                                    urlCon.getContentEncoding(),
                                    urlCon.getInputStream()
                            );

                        } catch (Exception e) {
                            return super.shouldInterceptLoadRequest(view, request);
                        }
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(XWalkView view, String url) {
                        canGoBack = webView.getNavigationHistory().canGoBack();
                        canGoForward = webView.getNavigationHistory().canGoForward();
                        if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("file:///") || url.startsWith("javascript:")) {
                            return false;
                        } else if(!url.startsWith("file:///")) {
                            view.loadUrl("file:///android_asset/".concat(url));
                            return false;
                        } else if (url.startsWith("unity:")) {
                            String message = url.substring(6);
                            mWebViewPlugin.call("CallFromJS", message);
                            return true;
                        }
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        view.getContext().startActivity(intent);
                        return true;
                    }

                });

                webView.addJavascriptInterface(mWebViewPlugin, "Unity");

                XWalkSettings webSettings = webView.getSettings();
                webSettings.setSupportZoom(false);
                webSettings.setJavaScriptEnabled(true);

                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    webSettings.setAllowUniversalAccessFromFileURLs(true);
                }

                webSettings.setDatabaseEnabled(true);
                webSettings.setDomStorageEnabled(true);

//                String databasePath = webView.getContext().getDir("databases", Context.MODE_PRIVATE).getPath();
//                webSettings.setDatbasePath

                // if(transparent) {
                    // webView.setBackgroundColor(0x00000000);
                // }

                // if (layout == null) {
                    // layout = new FrameLayout(a);
                    // a.addContentView(
                            // layout,
                            // new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                                    // ViewGroup.LayoutParams.MATCH_PARENT)
                    // );
                    // layout.setFocusable(true);
                    // layout.setFocusableInTouchMode(true);
                // }
                // layout.addView(
                        // webView,
                        // new FrameLayout.LayoutParams(
                                // ViewGroup.LayoutParams.MATCH_PARENT,
                                // ViewGroup.LayoutParams.MATCH_PARENT,
                                // Gravity.NO_GRAVITY)
                // );
                // mWebView = webView;		
					
				if (layout == null) {
					layout = new FrameLayout(a);
					a.addContentView(
						layout,
						new LayoutParams(
							LayoutParams.MATCH_PARENT,
							LayoutParams.MATCH_PARENT));
					layout.setFocusable(true);
					layout.setFocusableInTouchMode(true);
				}
				layout.addView(
					webView,
					new FrameLayout.LayoutParams(
						LayoutParams.MATCH_PARENT,
						LayoutParams.MATCH_PARENT,
						Gravity.NO_GRAVITY));
				mWebView = webView;				
				
        }});

        final View activityRootView = a.getWindow().getDecorView().getRootView();
        activityRootView.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                android.graphics.Rect r = new android.graphics.Rect();
                //r will be populated with the coordinates of your view that area still visible.
                activityRootView.getWindowVisibleDisplayFrame(r);
                android.view.Display display = a.getWindowManager().getDefaultDisplay();
                // cf. http://stackoverflow.com/questions/9654016/getsize-giving-me-errors/10564149#10564149
                int h = 0;
                try {
                    Point size = new Point();
                    display.getSize(size);
                    h = size.y;
                } catch (java.lang.NoSuchMethodError err) {
                    h = display.getHeight();
                }
                int heightDiff = activityRootView.getRootView().getHeight() - (r.bottom - r.top);
                if (heightDiff > h / 3) { // assume that this means that the keyboard is on
                    UnityPlayer.UnitySendMessage(gameObject, "SetKeyboardVisible", "true");
                } else {
                    UnityPlayer.UnitySendMessage(gameObject, "SetKeyboardVisible", "false");
                }
            }
        });
    }

    public void Destroy() {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if( mWebView == null) {
                    return;
                }

                mWebView.stopLoading();
                layout.removeView(mWebView);
                mWebView.onDestroy();
                mWebView = null;
            }
        });
    }

    public void LoadURL(final String url) {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {public void run() {
            if (mWebView == null) {
                return;
            }
            if (mCustomHeaders != null &&
                    !mCustomHeaders.isEmpty()) {
                mWebView.loadUrl(url, mCustomHeaders);
            } else {
                mWebView.loadUrl(url);;
            }
        }});
    }

    public void LoadHTML(final String html, final String baseURL)
    {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {public void run() {
            if (mWebView == null) {
                return;
            }
            mWebView.loadDataWithBaseURL(baseURL, html, "text/html", "UTF8", null);
        }});
    }

    public void EvaluateJS(final String js) {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {public void run() {
            if (mWebView == null) {
                return;
            }
            mWebView.loadUrl("javascript:" + js);
//            mWebView.evaluateJavascript(js, new ValueCallback<String>() {
//                @Override
//                public void onReceiveValue(String value) {
//                    Log.d("JavaScript Eval", value);
//                }
//            });
        }});
    }

    public void GoBack() {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {public void run() {
            if (mWebView == null) {
                return;
            }
            mWebView.getNavigationHistory().navigate(XWalkNavigationHistory.Direction.BACKWARD, 1);
        }});
    }

    public void GoForward() {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {public void run() {
            if (mWebView == null) {
                return;
            }
            mWebView.getNavigationHistory().navigate(XWalkNavigationHistory.Direction.FORWARD, 1);
        }});
    }

    public void SetMargins(int left, int top, int right, int bottom) {
        final FrameLayout.LayoutParams params
                = new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.MATCH_PARENT,
                Gravity.NO_GRAVITY);
        params.setMargins(left, top, right, bottom);
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {public void run() {
            if (mWebView == null) {
                return;
            }
            mWebView.setLayoutParams(params);
        }});
    }

    public void SetVisibility(final boolean visibility) {
        final Activity a = UnityPlayer.currentActivity;
        a.runOnUiThread(new Runnable() {public void run() {
            if (mWebView == null) {
                return;
            }
            if (visibility) {
                mWebView.setVisibility(View.VISIBLE);
                layout.requestFocus();
                mWebView.requestFocus();
            } else {
                mWebView.setVisibility(View.GONE);
            }
        }});
    }

    public void AddCustomHeader(final String headerKey, final String headerValue)
    {
        if (mCustomHeaders == null) {
            return;
        }
        mCustomHeaders.put(headerKey, headerValue);
    }

    public String GetCustomHeaderValue(final String headerKey)
    {
        if (mCustomHeaders == null) {
            return null;
        }

        if (!mCustomHeaders.containsKey(headerKey)) {
            return null;
        }
        return this.mCustomHeaders.get(headerKey);
    }

    public void RemoveCustomHeader(final String headerKey)
    {
        if (mCustomHeaders == null) {
            return;
        }

        if (this.mCustomHeaders.containsKey(headerKey)) {
            this.mCustomHeaders.remove(headerKey);
        }
    }

    public void ClearCustomHeader()
    {
        if (mCustomHeaders == null) {
            return;
        }

        this.mCustomHeaders.clear();
    }

}
