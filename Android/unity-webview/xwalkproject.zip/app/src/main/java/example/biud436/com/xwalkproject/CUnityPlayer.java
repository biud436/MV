package example.biud436.com.xwalkproject;

import android.content.ContextWrapper;
import android.view.SurfaceView;
import android.view.View;

import com.unity3d.player.UnityPlayer;

/**
 * Created by U on 2017-05-13.
 */
public class CUnityPlayer extends UnityPlayer {
    public CUnityPlayer(ContextWrapper contextWrapper) {
        super(contextWrapper);
    }

    public void addView(View child) {
        if( child instanceof SurfaceView) {
            ((SurfaceView)child).setZOrderOnTop(false);
        }
        super.addView(child);
    }
}
