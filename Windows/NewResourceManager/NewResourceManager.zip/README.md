# Terms of Use
Free for commercial and non-commercial use.

# License
The MIT License (MIT)

# Icon
The icon image has provided at the following link and then its license is CC-BY-SA-3.0.

- Site : https://www.iconfinder.com/icons/84569/eyedropper_icon
- License : https://creativecommons.org/licenses/by-sa/3.0/